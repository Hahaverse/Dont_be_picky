using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ScenesManager : MonoBehaviour
{
    private GameManager manager;
    private AudioManager audioManager;
    public static ScenesManager instance;
    #region Singleton
    private void Awake()
    {
        if (instance == null)
        {
            DontDestroyOnLoad(this.gameObject);
            instance = this;
        }
        else
        {
            Destroy(this.gameObject);
        }
    }
    #endregion

    void Start()
    {
        manager = FindObjectOfType<GameManager>();
        audioManager = FindObjectOfType<AudioManager>();
    }

    public void SceneChanger(string _name) //Scene ��ȯ ���� �Լ�
    {
        SceneManager.LoadScene(_name);
        switch (_name) //���� ���� ������� ���
        {
            case "MapScene":
                audioManager.PlayAudioLoop("Audio/BGM_Map");
                break;
            case "CafeScene":
                audioManager.PlayAudioLoop("Audio/BGM_Cafe");
                break;
            case "ResultScene":
                audioManager.StopAudio();
                break;
        }
    }
}
