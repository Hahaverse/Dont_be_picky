using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjData : MonoBehaviour
{
    public string _name; //�̸�
    public int id; //���̵�
}
