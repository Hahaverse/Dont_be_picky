using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class CounterHandler : MonoBehaviour, IPointerClickHandler
{

    private DatabaseManager theDatabase;
    private OrderManager theOrder;

    public void OnPointerClick(PointerEventData eventData)
    {
        theOrder.getOrder(); //�ֹ��� �ޱ�
    }

    void Start()
    {
        theDatabase = FindObjectOfType<DatabaseManager>();
        theOrder = FindObjectOfType<OrderManager>();
    }
}
