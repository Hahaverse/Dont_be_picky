using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationController : MonoBehaviour
{
    private Animator[] animators;
    private AnimatorStateInfo[] animatorStates;
    private float[] playbackTimes;

    private void Awake()
    {
        animators = GetComponentsInChildren<Animator>();
        animatorStates = new AnimatorStateInfo[animators.Length];
        playbackTimes = new float[animators.Length];
    }

    private void OnDisable()
    {
        // �ڽ� ������Ʈ�� �ִϸ��̼� ���� ����
        SaveAnimationState();
    }

    private void OnEnable()
    {
        // �ڽ� ������Ʈ�� �ִϸ��̼� ���� ����
        RestoreAnimationState();
    }

    private void SaveAnimationState()
    {
        for (int i = 0; i < animators.Length; i++)
        {
            if (animators[i] != null)
            {
                animatorStates[i] = animators[i].GetCurrentAnimatorStateInfo(0);
                playbackTimes[i] = animatorStates[i].normalizedTime;
            }
        }
    }

    private void RestoreAnimationState()
    {
        for (int i = 0; i < animators.Length; i++)
        {
            if (animators[i] != null)
            {
                animators[i].Play(animatorStates[i].fullPathHash, 0, playbackTimes[i]);
            }
        }
    }
}
