using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Day : MonoBehaviour
{
    public Text DayText; //��¥ ǥ�� txt

    void Start()
    {
        DayText.text = "Day " + GameData.day.ToString(); //���� ��¥ ǥ��
    }
}
